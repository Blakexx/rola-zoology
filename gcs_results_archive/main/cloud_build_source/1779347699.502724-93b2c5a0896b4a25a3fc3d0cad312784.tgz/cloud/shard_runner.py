"""Generic shard runner for Vertex AI CustomJobs.

Takes a workload-agnostic spec via CLI args + env vars and runs the
caller-specified `run_*.py` over a slice (`--shard N/M`) of its configs,
writing results to a GCS path so multiple shards can resume safely.

Usage (typically passed by submit.py):
  python cloud/shard_runner.py \
      --runner run_zoology_canonical_scan.py \
      --shard 0/4 \
      --gcs-results gs://bucket/path/results.jsonl \
      [--extra-env KEY=VAL ...]

The runner module must expose a `load_configs_and_envs()` or `configs` global,
and a `run_one(idx, run_id, cfg, env_overrides=None)` (the standard pattern in
our run_*.py scripts).

This wrapper:
  1. Imports the runner module.
  2. Pulls completed-OK idx set from the GCS results file (resume).
  3. For each idx, runs `i % M == N` only.
  4. Appends each result line to local file + uploads to GCS.
"""
import argparse
import importlib.util
import json
import os
import re
import sys
import time
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = THIS_DIR.parent
sys.path.insert(0, str(PROJECT_ROOT))


def _maybe_gcs_client():
    try:
        from google.cloud import storage
        return storage.Client()
    except Exception as e:
        print(f"WARN: google-cloud-storage not usable: {e}", flush=True)
        return None


def _read_gcs(client, gcs_uri):
    bucket_name, blob_name = gcs_uri[5:].split('/', 1)
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    if not blob.exists():
        return ""
    return blob.download_as_text()


def _append_gcs(client, gcs_uri, text):
    """Append a line to a GCS object. Idempotent-ish via download+rewrite."""
    bucket_name, blob_name = gcs_uri[5:].split('/', 1)
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    current = blob.download_as_text() if blob.exists() else ""
    blob.upload_from_string(current + text, content_type='application/jsonl')


def load_runner(runner_path: str):
    p = (PROJECT_ROOT / runner_path).resolve()
    spec = importlib.util.spec_from_file_location("runner", str(p))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--runner', required=True,
                   help='Path to the run_*.py script (relative to project root)')
    p.add_argument('--shard', default='0/1',
                   help='N/M — process configs where i %% M == N')
    p.add_argument('--gcs-results', required=True,
                   help='GCS path for results JSONL (gs://bucket/path/file.jsonl)')
    p.add_argument('--extra-env', action='append', default=[],
                   help='KEY=VAL env to apply to every subprocess (repeatable)')
    p.add_argument('--max-runs', type=int, default=None,
                   help='Stop after N runs (testing)')
    return p.parse_args()


def main():
    args = parse_args()
    shard_n, shard_m = map(int, args.shard.split('/'))
    print(f"[shard_runner] runner={args.runner} shard={shard_n}/{shard_m}", flush=True)
    print(f"[shard_runner] gcs_results={args.gcs_results}", flush=True)

    # Apply extra env (e.g. project-wide MQAR_* overrides) before importing runner.
    for kv in args.extra_env:
        if '=' in kv:
            k, v = kv.split('=', 1)
            os.environ[k] = v
            print(f"[shard_runner] env: {k}={v}", flush=True)

    runner = load_runner(args.runner)
    # Standard interface: runner has `configs` + `configs_envs` (or `load_configs_and_envs`).
    if hasattr(runner, 'load_configs_and_envs'):
        configs, envs = runner.load_configs_and_envs()
    else:
        configs = runner.configs
        envs = getattr(runner, 'configs_envs', [{} for _ in configs])

    total = len(configs)
    print(f"[shard_runner] loaded {total} configs", flush=True)

    # Resume: read completed-OK indices from the GCS results.
    gcs_client = _maybe_gcs_client() if args.gcs_results.startswith('gs://') else None
    completed = set()
    if gcs_client and args.gcs_results.startswith('gs://'):
        text = _read_gcs(gcs_client, args.gcs_results)
        for line in text.splitlines():
            try:
                r = json.loads(line)
                if r.get('ok'):
                    completed.add(r['idx'])
            except Exception:
                pass
        print(f"[shard_runner] resume: skipping {len(completed)} already-OK indices", flush=True)
    else:
        # Local file fallback if gcs not available.
        local_path = Path(args.gcs_results)
        if local_path.exists():
            for line in open(local_path):
                try:
                    r = json.loads(line)
                    if r.get('ok'): completed.add(r['idx'])
                except Exception: pass
            print(f"[shard_runner] resume (local): skipping {len(completed)}", flush=True)

    # Local mirror for this shard — also useful for logs.
    local_mirror = Path(f"/tmp/shard_{shard_n}_of_{shard_m}.jsonl")
    local_mirror.parent.mkdir(parents=True, exist_ok=True)

    runs_done = 0
    for i in range(total):
        if i % shard_m != shard_n:
            continue
        if i in completed:
            continue
        if args.max_runs is not None and runs_done >= args.max_runs:
            break

        cfg = configs[i]
        env_o = dict(envs[i] if i < len(envs) else {})  # shallow-copy to mutate safely
        run_id = getattr(cfg, 'run_id', f'idx{i}')
        # Per-run RESUME_STATE_URI for spot-preemption checkpointing. The
        # results.jsonl lives at gs://bucket/<sweep>/results.jsonl; we put
        # in-progress state next to it at gs://bucket/<sweep>/in_progress/<run_id>.pt
        if args.gcs_results.startswith("gs://"):
            base = args.gcs_results.rsplit("/", 1)[0]  # gs://bucket/<sweep>
            env_o["RESUME_STATE_URI"] = f"{base}/in_progress/{run_id}.pt"
        print(f"\n[shard_runner] [{i+1}/{total}] {run_id}  shard={shard_n}/{shard_m}", flush=True)

        # Delegate to the runner's own `run_one`. Each runner has this.
        # Signature varies slightly — some take (idx, run_id, cfg, env), some (idx, run_id, cfg).
        try:
            import inspect
            sig = inspect.signature(runner.run_one)
            kwargs = {}
            params = list(sig.parameters)
            if 'env_overrides' in params:
                kwargs['env_overrides'] = env_o
            result = runner.run_one(i, run_id, cfg, **kwargs)
        except Exception as e:
            result = {
                "run_id": run_id, "idx": i, "ok": False, "elapsed": 0,
                "error": f"shard_runner exception: {type(e).__name__}: {e}",
            }

        line = json.dumps(result) + "\n"
        # Local mirror append (cheap).
        with open(local_mirror, 'a') as fout:
            fout.write(line)
        # GCS append (slow-ish but safe).
        if gcs_client and args.gcs_results.startswith('gs://'):
            for attempt in range(3):
                try:
                    _append_gcs(gcs_client, args.gcs_results, line)
                    break
                except Exception as e:
                    print(f"[shard_runner] GCS append fail attempt {attempt+1}: {e}", flush=True)
                    time.sleep(2 ** attempt)
        else:
            with open(args.gcs_results, 'a') as fout:
                fout.write(line)

        runs_done += 1
        status = "OK" if result.get('ok') else f"FAIL ({result.get('error', result.get('returncode'))})"
        print(f"  → {status}, max_acc={result.get('max_acc', 0):.3f}, "
              f"grok_ep={result.get('grok_ep')}, t={result.get('elapsed', 0):.0f}s", flush=True)

    print(f"\n[shard_runner] done — completed {runs_done} runs on this shard", flush=True)


if __name__ == '__main__':
    main()
