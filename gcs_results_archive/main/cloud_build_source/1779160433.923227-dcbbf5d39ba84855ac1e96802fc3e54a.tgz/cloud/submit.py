"""Submit N parallel Vertex AI CustomJobs, each running a shard of a workload.

Generic — knows nothing about specific run scripts. Pass any workload via flags:

    python cloud/submit.py \
        --runner run_zoology_canonical_scan.py \
        --num-shards 4 \
        --gcs-results gs://my-bucket/zoology_canonical/results.jsonl \
        --machine a2-highgpu-1g \
        --accelerator NVIDIA_TESLA_A100 \
        --spot

Reads cloud/.env for project/region/bucket defaults (so no secrets in source).
"""
import argparse
import os
import sys
from pathlib import Path

# Load cloud/.env if present (KEY=VAL pairs).
ENV_FILE = Path(__file__).resolve().parent / '.env'
if ENV_FILE.exists():
    for line in open(ENV_FILE):
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        os.environ.setdefault(k.strip(), v.strip())


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--runner', required=True,
                   help='run_*.py script to invoke (e.g. run_zoology_canonical_scan.py)')
    p.add_argument('--num-shards', type=int, default=1,
                   help='Number of parallel CustomJobs to submit')
    p.add_argument('--gcs-results', required=True,
                   help='gs://bucket/path/results.jsonl — all shards append here')
    p.add_argument('--machine', default='a2-highgpu-1g',
                   help='Vertex machine type (default a2-highgpu-1g = 1× A100 40GB)')
    p.add_argument('--accelerator', default='NVIDIA_TESLA_A100',
                   help='Accelerator type (default NVIDIA_TESLA_A100)')
    p.add_argument('--accelerator-count', type=int, default=1)
    p.add_argument('--spot', action='store_true', help='Use spot (preemptible) pricing')
    p.add_argument('--max-runs-per-shard', type=int, default=None,
                   help='Cap runs per shard — testing')
    p.add_argument('--extra-env', action='append', default=[],
                   help='KEY=VAL env passed through to every shard (repeatable)')
    p.add_argument('--display-name-prefix', default='cla-sweep',
                   help='Vertex job display name prefix')
    p.add_argument('--image-tag', default=os.environ.get('IMAGE_TAG', 'latest'),
                   help='Docker image tag')
    p.add_argument('--dry-run', action='store_true', help='Print job specs and exit')
    return p.parse_args()


def main():
    args = parse_args()
    project = os.environ.get('GCP_PROJECT_ID')
    region = os.environ.get('GCP_REGION', 'us-central1')
    ar_repo = os.environ.get('AR_REPO', 'cla-sweep')
    if not project:
        sys.exit("ERROR: GCP_PROJECT_ID not set. Configure cloud/.env.")
    if not args.gcs_results.startswith('gs://'):
        sys.exit("ERROR: --gcs-results must be a gs:// URI")

    image_uri = f"{region}-docker.pkg.dev/{project}/{ar_repo}/sweep:{args.image_tag}"
    print(f"Project:     {project}")
    print(f"Region:      {region}")
    print(f"Image:       {image_uri}")
    print(f"Runner:      {args.runner}")
    print(f"GCS results: {args.gcs_results}")
    print(f"Shards:      {args.num_shards}")
    print(f"Machine:     {args.machine}")
    print(f"Accelerator: {args.accelerator} × {args.accelerator_count}")
    print(f"Spot:        {args.spot}")

    if args.dry_run:
        print("\n[dry-run] would submit:")
        for i in range(args.num_shards):
            container_args = build_container_args(args, i)
            print(f"  shard {i}: {container_args}")
        return

    # Import the SDK only when actually submitting (no need for dry-run).
    from google.cloud import aiplatform
    aiplatform.init(project=project, location=region)

    jobs = []
    for i in range(args.num_shards):
        container_args = build_container_args(args, i)
        display_name = f"{args.display_name_prefix}-{args.runner.replace('.py','').replace('run_','')}-{i}of{args.num_shards}"

        worker_pool_specs = [{
            "machine_spec": {
                "machine_type": args.machine,
                "accelerator_type": args.accelerator,
                "accelerator_count": args.accelerator_count,
            },
            "replica_count": 1,
            "container_spec": {
                "image_uri": image_uri,
                "args": container_args,
            },
        }]

        job = aiplatform.CustomJob(
            display_name=display_name,
            worker_pool_specs=worker_pool_specs,
            project=project,
            location=region,
        )

        scheduling_kwargs = {}
        if args.spot:
            # Spot scheduling on Vertex: use the new `strategy` field.
            scheduling_kwargs['scheduling_strategy'] = 'SPOT'
        # Submit async (don't block).
        job.submit(**scheduling_kwargs) if scheduling_kwargs else job.submit()
        print(f"submitted [{i}/{args.num_shards}] {display_name}  resource={job.resource_name}")
        jobs.append(job)

    print(f"\nAll {args.num_shards} jobs submitted. Watch progress in the Vertex AI console:")
    print(f"  https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={project}")


def build_container_args(args, shard_idx):
    out = [
        '--runner', args.runner,
        '--shard', f"{shard_idx}/{args.num_shards}",
        '--gcs-results', args.gcs_results,
    ]
    if args.max_runs_per_shard is not None:
        out += ['--max-runs', str(args.max_runs_per_shard)]
    for kv in args.extra_env:
        out += ['--extra-env', kv]
    return out


if __name__ == '__main__':
    main()
