"""RLA Extreme — sharp test of P2 (decoupling) at LARGE matched state.

Hypothesis: CLA's value should appear at the diminishing-returns regime of
single-state RLA. We've measured up to state ≈ 16k (d=64 baseline) and CLA
hasn't beaten matched-state RLA. The question: does the curve flatten further
out at state ~150k?

Three architectures at matched state ≈ 153,600 floats per layer (V+1 norm):
  cla-rla-d24-nc64 : 4·64·24·25 = 153,600  (chunks of narrow d)
  rla-d1536-dv24   : 4· 1·1536·25 = 153,600  (wide asymmetric — wide d_qk, narrow d_v)
  rla-d196-dv196   : 4· 1·196·197 = 154,448  (wide symmetric, 0.5% over)

Smoke verified all three instantiate + forward cleanly at d_model=128, n_heads=4.

PARAM-COUNT NOTE: matched state ≠ matched params. Wider d_qk grows the Q/K
projection significantly. RLA-d1536-dv24 has ~2.4× the params of CLA-d24-nc64.
This is an inherent architectural property; reported in results table.

3 cells × 4 LRs × 5 seeds = 60 runs.
"""
from zoology.config import TrainConfig, ModelConfig, ModuleConfig, LoggerConfig
from zoology.experiments.rla_sweep import (
    data, data_small_batch, wrap_hybrid, cla_rla,
    LRS, SEEDS, D_MODEL, VOCAB,
)


def rla_asymmetric(d_qk: int, d_v: int):
    """RLA with asymmetric d_qk != d_v (e.g., wide d_qk, narrow d_v)."""
    return dict(
        name="zoology.mixers.cla.RecurrentLinearAttention",
        kwargs={"d_qk": d_qk, "d_v": d_v, "n_heads": 4},
    )


# Cells. The CLA cell already exists in rla_sweep.py CELLS but we re-list it
# here for self-contained run.
CELLS = [
    # SMOKE: cla-rla-d24-nc16 — moderate nc to check cloud Triton works before
    # attempting nc=64 (which failed with "Triton CUDA invalid argument").
    # State = 4·16·24·25 = 38,400 (NOT matched to the other cells; pure smoke).
    ("cla-rla-d24-nc16",   cla_rla(24, 16),               {}),  # 38,400 (smoke)
    ("cla-rla-d24-nc64",   cla_rla(24, 64),               {}),  # 153,600
    ("rla-d1536-dv24",     rla_asymmetric(1536, 24),      {}),  # 153,600
    ("rla-d196-dv196",     rla_asymmetric(196, 196),      {}),  # 154,448
]

# d_qk=1536 has very wide Q/K activations — at B=256, T=256, fp32:
# Q intermediate = 256·256·4·1536·4 = 1.6 GB. Plus K = 1.6 GB. Tight on 12 GB.
# Drop to batch=128 to be safe.
OOM_CELLS = {"rla-d1536-dv24"}

configs = []
configs_envs = []
for name, kernel, env in CELLS:
    mixer = wrap_hybrid(kernel)
    cell_data = data_small_batch if name in OOM_CELLS else data
    for lr in LRS:
        for seed in SEEDS:
            configs.append(
                TrainConfig(
                    data=cell_data,
                    model=ModelConfig(
                        block_type="TransformerBlock",
                        sequence_mixer=mixer,
                        state_mixer=ModuleConfig(name="torch.nn.Identity", kwargs={}),
                        d_model=D_MODEL, n_layers=2,
                        max_position_embeddings=0,
                        vocab_size=VOCAB,
                    ),
                    logger=LoggerConfig(project_name="rla-extreme", entity=""),
                    max_epochs=32, learning_rate=lr, weight_decay=0.0, seed=seed,
                    run_id=f"{name}_lr{lr:.2e}_s{seed}",
                    early_stopping_threshold=0.99,
                    early_stopping_metric="valid/accuracy",
                    slice_keys=["num_kv_pairs"],
                )
            )
            configs_envs.append(env)

assert len(configs) == 80, f"expected 80 configs (4 cells × 20), got {len(configs)}"


def load_configs_and_envs():
    return configs, configs_envs
