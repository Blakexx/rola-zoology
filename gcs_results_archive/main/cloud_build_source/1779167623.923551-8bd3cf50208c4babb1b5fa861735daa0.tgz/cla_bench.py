import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import matplotlib.pyplot as plt
import numpy as np
import random
import time
import math
import os
import sys
import warnings

# Suppress the misleading FLA deprecation warning
warnings.filterwarnings("ignore", message="Input tensor shape suggests potential format mismatch.*")

# ========================================== 
# 0. Logging and Device Configuration
# ========================================== 

def get_device():
    if torch.cuda.is_available():
        return torch.device('cuda')
    elif torch.backends.mps.is_available():
        return torch.device('mps') 
    else:
        return torch.device('cpu')

DEVICE = get_device()

# Optional libraries
try:
    from datasets import load_dataset
    HAS_HF_DATASETS = True
except ImportError:
    HAS_HF_DATASETS = False

# FLA kernels
from fla.ops.retention import chunk_retention, fused_chunk_retention, fused_recurrent_retention
from fla.ops.linear_attn import chunk_linear_attn, fused_chunk_linear_attn, fused_recurrent_linear_attn
from fla.ops.gla import chunk_gla
from fla.ops.gated_delta_rule import chunk_gated_delta_rule

# ==========================================
# 1. Dataset Handling
# ==========================================
class MQARDataset(Dataset):
    """
    Multi-Query Associative Recall (Zoology / Based / MoM lingua franca).

    Layout:  [k_0 v_0 k_1 v_1 ... k_{N-1} v_{N-1} | k_q1 v_q1 k_q2 v_q2 ... k_qM v_qM]
             |---- setup section (2*num_kv) ----|---- queries section (2*num_queries) ----|

    The model sees the setup, then sees query keys (sampled with replacement from the
    setup keys), and must predict each query's value at the *query-key* position.
    Values for queries are placed at qpos+1 so the model can autoregress through them.

    Vocab is split: key tokens [0, num_kv), value tokens [num_kv, 2*num_kv).
    Loss is masked to query-key positions only via ignore_index=-100.
    """
    def __init__(self, num_kv, num_queries, vocab_size, num_examples, seed=0):
        self.num_kv = num_kv
        self.num_queries = num_queries
        self.length = 2 * num_kv + 2 * num_queries
        self.vocab_size = vocab_size
        self.num_examples = num_examples
        self.seed = seed
        assert vocab_size >= 2 * num_kv, f"vocab_size={vocab_size} must be >= 2*num_kv={2*num_kv}"

    def __len__(self):
        return self.num_examples

    def __getitem__(self, idx):
        rng = np.random.default_rng(self.seed * 1_000_003 + idx)
        # Permute keys and values so the (key_i -> value_i) mapping is fresh each example.
        keys = rng.permutation(self.num_kv).astype(np.int64)
        values = (self.num_kv + rng.permutation(self.num_kv)).astype(np.int64)

        L = self.length
        x = np.zeros(L, dtype=np.int64)
        y = np.full(L, -100, dtype=np.int64)

        # Setup section: k_0 v_0 k_1 v_1 ...
        for i in range(self.num_kv):
            x[2*i]     = keys[i]
            x[2*i + 1] = values[i]

        # Queries section: sample num_queries query indices (with replacement), place
        # k_q v_q pairs back-to-back. Loss is on the k_q positions, predicting v_q.
        query_indices = rng.integers(0, self.num_kv, size=self.num_queries)
        qstart = 2 * self.num_kv
        for j, qidx in enumerate(query_indices):
            qpos = qstart + 2 * j
            x[qpos]     = keys[qidx]
            x[qpos + 1] = values[qidx]
            y[qpos]     = values[qidx]

        return torch.from_numpy(x), torch.from_numpy(y)


class TextDatasetProvider:
    def __init__(self, dataset_name='shakespeare', seq_len=128):
        self.dataset_name = dataset_name
        self.seq_len = seq_len
        self.train_data = None
        self.val_data = None
        self.is_mqar = False

        if dataset_name == 'mqar':
            self._build_mqar_dataset()
            return

        if not HAS_HF_DATASETS:
            raise ImportError("This script requires the 'datasets' library from Hugging Face. Please install it.")

        if dataset_name == 'shakespeare':
            self._build_shakespeare_dataset()
        elif dataset_name == 'wikitext':
            self._build_wikitext_dataset()
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")

    def _build_mqar_dataset(self):
        log_print("Building MQAR (Multi-Query Associative Recall) synthetic dataset...")
        self.is_mqar = True
        self.num_kv = int(os.environ.get('MQAR_NUM_KV', 16))
        self.num_queries = self.num_kv
        self.vocab_size = 2 * self.num_kv  # 32
        self.train_ds = MQARDataset(self.num_kv, self.num_queries,
                                    self.vocab_size, num_examples=20000, seed=1)
        self.val_ds   = MQARDataset(self.num_kv, self.num_queries,
                                    self.vocab_size, num_examples=1000, seed=99999)
        self.seq_len = self.train_ds.length  # 2*num_kv + 2*num_queries = 64
        log_print(f"MQAR: vocab={self.vocab_size}, seq_len={self.seq_len}, "
                  f"num_kv={self.num_kv}, num_queries={self.num_queries}")

    def _build_shakespeare_dataset(self):
        log_print("Loading Tiny Shakespeare dataset (char-level)...")
        self.seq_len = 128
        
        import requests
        url = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"
        log_print("Downloading from GitHub...")
        text = requests.get(url).text
        
        # Character-level tokenizer
        chars = sorted(list(set(text)))
        self.vocab_size = len(chars)
        self.stoi = {ch: i for i, ch in enumerate(chars)}
        self.itos = {i: ch for i, ch in enumerate(chars)}
        
        full_data = torch.tensor([self.stoi[c] for c in text], dtype=torch.long)
        
        # Explicit 90/10 split for Shakespeare
        split_idx = int(0.9 * len(full_data))
        self.train_data = full_data[:split_idx]
        self.val_data = full_data[split_idx:]
        
        log_print(f"Loaded Shakespeare. Vocab size: {self.vocab_size}")
        log_print(f"Train tokens: {len(self.train_data)}, Val tokens: {len(self.val_data)}")

    def _build_wikitext_dataset(self):
        log_print("Loading WikiText-2 dataset (word-level)...")
        self.seq_len = 256
        
        # Load explicit splits from Hugging Face
        train_split = load_dataset("wikitext", "wikitext-2-raw-v1", split='train')
        val_split = load_dataset("wikitext", "wikitext-2-raw-v1", split='validation')
        
        # Build vocabulary from training data only to prevent leakage
        train_text = "\n".join([line for line in train_split['text'] if line.strip()])
        val_text = "\n".join([line for line in val_split['text'] if line.strip()])

        words = train_text.split()
        vocab = {word: count for word, count in zip(*np.unique(words, return_counts=True))}
        
        # Keep top words + <unk> token
        vocab_size = 10000 
        top_words = sorted(vocab.keys(), key=lambda k: vocab[k], reverse=True)[:vocab_size-1]
        
        self.stoi = {word: i for i, word in enumerate(top_words)}
        self.stoi['<unk>'] = vocab_size - 1
        self.itos = {i: word for word, i in self.stoi.items()}
        self.vocab_size = vocab_size
        
        unk_idx = self.stoi['<unk>']
        
        # Encode both splits
        train_words = train_text.split()
        val_words = val_text.split()
        
        self.train_data = torch.tensor([self.stoi.get(w, unk_idx) for w in train_words], dtype=torch.long)
        self.val_data = torch.tensor([self.stoi.get(w, unk_idx) for w in val_words], dtype=torch.long)
        
        log_print(f"Loaded WikiText-2. Vocab size: {self.vocab_size}")
        log_print(f"Train tokens: {len(self.train_data)}, Val tokens: {len(self.val_data)}")

    def get_loaders(self, batch_size=32):
        if self.is_mqar:
            train_loader = DataLoader(self.train_ds, batch_size=batch_size, shuffle=True)
            val_loader = DataLoader(self.val_ds, batch_size=batch_size)
            return train_loader, val_loader

        class CustomTensorDataset(Dataset):
            def __init__(self, data, seq_len):
                self.data = data
                self.seq_len = seq_len
            def __len__(self):
                return max(0, len(self.data) - self.seq_len - 1)
            def __getitem__(self, idx):
                chunk = self.data[idx : idx + self.seq_len + 1]
                return chunk[:-1], chunk[1:]

        # Use the pre-split data
        train_ds = CustomTensorDataset(self.train_data, self.seq_len)
        val_ds = CustomTensorDataset(self.val_data, self.seq_len)

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size)

        return train_loader, val_loader
# ========================================== 
# 2. Attention Mechanisms
# ========================================== 

class RecurrentLinearAttention(nn.Module):
    """
    Enhanced Recurrent Linear Attention (RLA).
    
    Improvements over Standard RLA:
    1. NORMALIZATION: Uses the "V+1 Denominator Trick" for stable weighted averaging.
    2. POSITIVITY: Applies ELU+1 to Q/K to ensure strictly positive attention weights.
    """
    def __init__(self, d_model, d_qk, d_v, n_heads=4, **kwargs):
        super().__init__()
        self.d_model = d_model
        self.d_qk = d_qk
        self.d_v = d_v
        self.n_heads = n_heads
        
        # Projection output size: Heads * State_Dim
        self.dim_inner_qk = n_heads * d_qk
        self.dim_inner_v = n_heads * d_v

        self.w_q = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_k = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_v = nn.Linear(d_model, self.dim_inner_v, bias=False)
        
        self.w_o = nn.Linear(self.dim_inner_v, d_model, bias=False)

    def forward(self, x):
        # x: [Batch, Length, Dim]
        B, L, _ = x.shape
        H = self.n_heads
        
        # 1. Project and reshape to [B, L, H, D]
        q = self.w_q(x).view(B, L, H, self.d_qk)
        k = self.w_k(x).view(B, L, H, self.d_qk)
        v = self.w_v(x).view(B, L, H, self.d_v)

        # 2. Enforce Positivity (Critical for Denominator Trick)
        # Guarantees that Q * K^T > 0, preventing zero/negative divisors.
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0

        # 3. The Denominator Trick (RWKV-Style)
        # Append 1.0 to V to track the sum of weights.
        # Shape: [B, L, H, D+1]
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)

        # 4. Kernel Call
        raw_out, _ = fused_chunk_linear_attn(q, k, v_aug, normalize=False, scale=1.0)

        # 5. Normalization
        # Split Signal (num) and Weight Mass (den)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        
        # Stable Division
        out = num / (den + 1e-5) 

        # 6. Output Projection
        out = out.reshape(B, L, self.dim_inner_v)
        return self.w_o(out)

    def get_stats(self):
        """Returns a dictionary of key hyperparameters and calculated state size."""
        # For RLA, num_chunks is effectively 1
        state_floats = self.n_heads * 1 * (self.d_qk * self.d_v + self.d_qk)
        return {
            'd_qk': self.d_qk,
            'd_v': self.d_v,
            'n_heads': self.n_heads,
            'num_chunks': 1, # RLA is not chunked
            'state_floats': state_floats
        }

    def state_size(self, sequence_length: int = None, **kwargs) -> int:
        # Zoology's Hybrid.state_size / model.state_size_total call this on
        # every mixer. Recurrent state is independent of sequence_length.
        return self.get_stats()['state_floats']


class RecurrentGLA(nn.Module):
    """Single-state Gated Linear Attention. Adds a learnable per-(head,key-dim) forget gate.

    State update: S_t = diag(g_t) · S_{t-1} + k_t^T v_t   with g_t = sigmoid(w_g x_t) in (0,1).
    V+1 normalization still applied on the output.
    """
    def __init__(self, d_model, d_qk, d_v, n_heads=4, use_short_conv=False, conv_size=4, **kwargs):
        super().__init__()
        self.d_model = d_model
        self.d_qk = d_qk
        self.d_v = d_v
        self.n_heads = n_heads
        self.dim_inner_qk = n_heads * d_qk
        self.dim_inner_v = n_heads * d_v
        self.w_q = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_k = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_v = nn.Linear(d_model, self.dim_inner_v, bias=False)
        self.w_g = nn.Linear(d_model, self.dim_inner_qk, bias=False)  # log-forget-gate per (head, d_qk)
        self.w_o = nn.Linear(self.dim_inner_v, d_model, bias=False)
        self.use_short_conv = use_short_conv
        if use_short_conv:
            self.conv_size = conv_size
            self.conv_pad = conv_size - 1
            self.q_conv = nn.Conv1d(self.dim_inner_qk, self.dim_inner_qk,
                                    kernel_size=conv_size, groups=self.dim_inner_qk, bias=False)
            self.k_conv = nn.Conv1d(self.dim_inner_qk, self.dim_inner_qk,
                                    kernel_size=conv_size, groups=self.dim_inner_qk, bias=False)
            self.v_conv = nn.Conv1d(self.dim_inner_v, self.dim_inner_v,
                                    kernel_size=conv_size, groups=self.dim_inner_v, bias=False)

    def forward(self, x):
        B, L, _ = x.shape
        H = self.n_heads
        q_raw = self.w_q(x)
        k_raw = self.w_k(x)
        v_raw = self.w_v(x)
        if self.use_short_conv:
            def _cconv(xx, conv):
                xx = xx.transpose(1, 2)
                xx = F.pad(xx, (self.conv_pad, 0))
                xx = conv(xx)
                return F.silu(xx.transpose(1, 2))
            q_raw = _cconv(q_raw, self.q_conv)
            k_raw = _cconv(k_raw, self.k_conv)
            v_raw = _cconv(v_raw, self.v_conv)
        q = F.elu(q_raw.view(B, L, H, self.d_qk)) + 1.0
        k = F.elu(k_raw.view(B, L, H, self.d_qk)) + 1.0
        v = v_raw.view(B, L, H, self.d_v)
        g = F.logsigmoid(self.w_g(x).view(B, L, H, self.d_qk))
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        raw_out, _ = chunk_gla(q, k, v_aug, g, scale=1.0)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out = num / (den + 1e-5)
        return self.w_o(out.reshape(B, L, self.dim_inner_v))

    def get_stats(self):
        state_floats = self.n_heads * 1 * (self.d_qk * self.d_v + self.d_qk)
        return {'d_qk': self.d_qk, 'd_v': self.d_v, 'n_heads': self.n_heads,
                'num_chunks': 1, 'state_floats': state_floats}

    def state_size(self, sequence_length: int = None, **kwargs) -> int:
        return self.get_stats()['state_floats']


class RecurrentGatedDelta(nn.Module):
    """Single-state Gated Delta Rule (the kernel MoM uses by default).

    State update: S_t = g_t · (I - k_t^T k_t) · S_{t-1} + β_t · k_t^T v_t
    No V+1 normalization (delta rule doesn't factor into simple weighted average).
    """
    def __init__(self, d_model, d_qk, d_v, n_heads=4, **kwargs):
        super().__init__()
        self.d_model = d_model
        self.d_qk = d_qk
        self.d_v = d_v
        self.n_heads = n_heads
        self.dim_inner_qk = n_heads * d_qk
        self.dim_inner_v = n_heads * d_v
        self.w_q = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_k = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_v = nn.Linear(d_model, self.dim_inner_v, bias=False)
        self.w_g = nn.Linear(d_model, n_heads, bias=False)     # scalar forget-gate per head
        self.w_beta = nn.Linear(d_model, n_heads, bias=False)  # scalar delta amplitude per head
        self.w_o = nn.Linear(self.dim_inner_v, d_model, bias=False)

    def forward(self, x):
        B, L, _ = x.shape
        H = self.n_heads
        q = self.w_q(x).view(B, L, H, self.d_qk)
        k = self.w_k(x).view(B, L, H, self.d_qk)
        v = self.w_v(x).view(B, L, H, self.d_v)
        g = F.logsigmoid(self.w_g(x).view(B, L, H))
        beta = torch.sigmoid(self.w_beta(x).view(B, L, H))
        out, _ = chunk_gated_delta_rule(q, k, v, g, beta, use_qk_l2norm_in_kernel=True)
        return self.w_o(out.reshape(B, L, self.dim_inner_v))

    def get_stats(self):
        # GDN has no V+1 denominator trick — state is just d_qk * d_v per head.
        state_floats = self.n_heads * 1 * (self.d_qk * self.d_v)
        return {'d_qk': self.d_qk, 'd_v': self.d_v, 'n_heads': self.n_heads,
                'num_chunks': 1, 'state_floats': state_floats}

    def state_size(self, sequence_length: int = None, **kwargs) -> int:
        return self.get_stats()['state_floats']


def _maybe_init_router(layer, role=None):
    """Optionally re-initialize a router Linear with normal(0, std).

    Lookup order for std:
      1. MQAR_ROUTER_STD_WRITE (if role='write')
      2. MQAR_ROUTER_STD_READ (if role='read')
      3. MQAR_ROUTER_STD (fallback, same for both)
      4. PyTorch default Kaiming-uniform
    """
    std = None
    if role == 'write':
        std = os.environ.get('MQAR_ROUTER_STD_WRITE')
    elif role == 'read':
        std = os.environ.get('MQAR_ROUTER_STD_READ')
    if std is None or std == 'default':
        std = os.environ.get('MQAR_ROUTER_STD', 'default')
    if std != 'default':
        nn.init.normal_(layer.weight, std=float(std))
        # Mark so Zoology's _init_weights skips overwriting (it would otherwise
        # reset every Linear weight to its default std=0.02 in model.apply()).
        layer.weight._no_reinit = True


def _maybe_init_router_param(W, role=None):
    """Init a per-head router Parameter (shape [H, d_in, C]) using the same env knobs."""
    std = None
    if role == 'write':
        std = os.environ.get('MQAR_ROUTER_STD_WRITE')
    elif role == 'read':
        std = os.environ.get('MQAR_ROUTER_STD_READ')
    if std is None or std == 'default':
        std = os.environ.get('MQAR_ROUTER_STD', 'default')
    with torch.no_grad():
        if std != 'default':
            W.normal_(0, float(std))
            W._no_reinit = True
        else:
            # Kaiming-style default for fan_in = d_in.
            d_in = W.shape[1]
            W.normal_(0, 1.0 / max(d_in, 1) ** 0.5)


class WriterBase(nn.Module):
    """Contract: forward(x, q, k, v) -> chunk_outputs of shape [B, L, H, C, d_v].

    The writer owns the per-chunk gating and the (optional) per-chunk normalization.
    Different writers can implement different gate activations, normalization
    strategies, and routing complexities (linear, MLP, etc.).

    Class-level flags (overridden by subclasses):
      uses_v_plus_one: state includes the V+1 denominator trick (LA/GLA style).

    Each writer applies any q/k activation it needs inside its own forward (e.g.
    ELU+1 for LA/GLA kernels that need positive q,k; none for GDN which L2-normalizes).
    """
    uses_v_plus_one = True

    def forward(self, x, q, k, v):
        raise NotImplementedError


class SoftmaxLinearWriter(WriterBase):
    """Default writer: linear router → softmax gates → V+1-normalized linear attention per chunk.

    route_on: 'x' (default; router takes the residual stream) or 'kq' (router takes
    the per-head k to decide which chunk to write into — aligns routing with the
    kernel's input representation, important when use_short_conv is on).
    """
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None, route_on='x'):
        super().__init__()
        self.n_heads = n_heads
        self.num_chunks = num_chunks
        self.d_qk = d_qk
        self.d_v = d_v
        self.route_on = route_on
        if route_on == 'kq':
            # Per-head router on k: W_route[h, :, :] maps d_qk -> C for head h.
            self.W_route = nn.Parameter(torch.empty(n_heads, d_qk, num_chunks))
            _maybe_init_router_param(self.W_route, role='write')
        elif router is None:
            self.router = nn.Linear(d_model, n_heads * num_chunks, bias=False)
            _maybe_init_router(self.router, role='write')
        else:
            # Shared with the reader (tied-router case).
            self.router = router

    def _write_gates(self, x, k):
        B, L = x.shape[0], x.shape[1]
        H, C = self.n_heads, self.num_chunks
        if self.route_on == 'kq':
            logits = torch.einsum('blhd,hdc->blhc', k, self.W_route)
        else:
            logits = self.router(x).view(B, L, H, C)
        return F.softmax(logits, dim=-1)

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        # Note: route on RAW k (pre-ELU), so routing sees the same input as the kernel's
        # learnable feature map. Then apply ELU+1 for the LA kernel which needs positive q,k.
        write_gates = self._write_gates(x, k)
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        # Expand q, k across chunks; gate v.
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)            # [B,L,H,d_v+1]
        v_virt = v_aug.unsqueeze(3) * write_gates.unsqueeze(-1)                # [B,L,H,C,d_v+1]
        # Flatten chunks into the kernel's head axis.
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v + 1)
        raw_out, _ = fused_chunk_linear_attn(q_flat, k_flat, v_flat, normalize=False, scale=1.0)
        # V+1 per-chunk normalization.
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out_flat = num / (den + 1e-5)
        return out_flat.view(B, L, H, C, self.d_v)


class ReaderBase(nn.Module):
    """Contract: forward(x, chunk_outputs) -> out of shape [B, L, H, d_v].

    The reader owns the merge from per-chunk outputs to a single per-token output.
    Different readers can implement different merge strategies (soft sum, MLP merge,
    cross-attention over chunks, etc.).
    """
    def forward(self, x, chunk_outputs):
        raise NotImplementedError


class SoftmaxLinearReader(ReaderBase):
    """Default reader: softmax-weighted sum over chunks.

    route_on: 'x' (default; router on residual stream) or 'kq' (router on per-head q
    to retrieve from the chunk whose key-space the query points at — aligns with
    attention semantics, important when use_short_conv is on).

    Optional hard-uniform override (env: MQAR_HARD_UNIFORM_READER_UNTIL=N).
    When current epoch < N, forward returns mean across chunks instead of the
    routed sum. The router's weights are also frozen during that window so they
    don't drift on uninformative gradient. Requires trainer to set
    `reader._current_epoch` each epoch.
    """
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None, route_on='x'):
        super().__init__()
        self.n_heads = n_heads
        self.num_chunks = num_chunks
        self.d_qk = d_qk
        self.route_on = route_on
        if route_on == 'kq':
            self.W_route = nn.Parameter(torch.empty(n_heads, d_qk, num_chunks))
            _maybe_init_router_param(self.W_route, role='read')
        elif router is None:
            self.router = nn.Linear(d_model, n_heads * num_chunks, bias=False)
            _maybe_init_router(self.router, role='read')
        else:
            self.router = router
        # Hard uniform reader phase 1 (optional).
        self._hard_uniform_until = int(os.environ.get(
            "MQAR_HARD_UNIFORM_READER_UNTIL", "0"))
        self._current_epoch = 0  # trainer sets this each epoch

    def forward(self, x, chunk_outputs, q=None):
        if self._current_epoch < self._hard_uniform_until:
            return chunk_outputs.mean(dim=3)
        B, L, H, C, _ = chunk_outputs.shape
        if self.route_on == 'kq':
            assert q is not None, "route_on='kq' requires q passed to reader"
            logits = torch.einsum('blhd,hdc->blhc', q, self.W_route)
        else:
            logits = self.router(x).view(B, L, H, C)
        read_gates = F.softmax(logits, dim=-1)
        return torch.sum(read_gates.unsqueeze(-1) * chunk_outputs, dim=3)


class CosineSoftmaxLinearReader(SoftmaxLinearReader):
    """Reader with cosine-similarity routing + learnable temperature.
    tau initialized at 1.0; model learns whether reads should be sharper (small tau)
    or softer (large tau). Expected: tau_read < tau_write (reads more competitive)."""
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None):
        super().__init__(d_model, n_heads, num_chunks, d_qk, d_v, router)
        self.tau = nn.Parameter(torch.ones(1))

    def forward(self, x, chunk_outputs):
        B, L, H, C, _ = chunk_outputs.shape
        logits = _cosine_logits(self.router, x, self.tau).view(B, L, H, C)
        read_gates = F.softmax(logits, dim=-1)
        return torch.sum(read_gates.unsqueeze(-1) * chunk_outputs, dim=3)


class SoftmaxGLAWriter(WriterBase):
    """CLA writer with GLA inner kernel: chunked GLA (forget-gated linear attention)."""
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None, route_on='x'):
        super().__init__()
        self.n_heads = n_heads
        self.num_chunks = num_chunks
        self.d_qk = d_qk
        self.d_v = d_v
        self.route_on = route_on
        if route_on == 'kq':
            self.W_route = nn.Parameter(torch.empty(n_heads, d_qk, num_chunks))
            _maybe_init_router_param(self.W_route, role='write')
        elif router is None:
            self.router = nn.Linear(d_model, n_heads * num_chunks, bias=False)
            _maybe_init_router(self.router, role='write')
        else:
            self.router = router
        # Forget-gate projection (shared across chunks)
        self.w_g = nn.Linear(d_model, n_heads * d_qk, bias=False)

    def _write_gates(self, x, k):
        B, L = x.shape[0], x.shape[1]
        H, C = self.n_heads, self.num_chunks
        if self.route_on == 'kq':
            logits = torch.einsum('blhd,hdc->blhc', k, self.W_route)
        else:
            logits = self.router(x).view(B, L, H, C)
        return F.softmax(logits, dim=-1)

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        # Route on raw k (pre-ELU) so routing sees the same conv-output the kernel sees,
        # then apply ELU+1 for the GLA kernel which needs positive q,k.
        write_gates = self._write_gates(x, k)
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        g = F.logsigmoid(self.w_g(x).view(B, L, H, self.d_qk))
        # alpha_chunk = 1 - w*(1-alpha): w=0 preserve (alpha=1), w=1 full decay (alpha).
        alpha = g.exp()  # [B, L, H, d_qk]
        alpha_chunk = 1.0 - write_gates.unsqueeze(-1) * (1.0 - alpha.unsqueeze(3))
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        v_virt = v_aug.unsqueeze(3) * write_gates.unsqueeze(-1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v + 1)
        raw_out, _ = chunk_gla(q_flat, k_flat, v_flat, g_flat, scale=1.0)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out_flat = num / (den + 1e-5)
        return out_flat.view(B, L, H, C, self.d_v)


class SoftmaxGLANoV1Writer(SoftmaxGLAWriter):
    """CLA-GLA writer WITHOUT V+1 normalization.

    Matches base GLA (FLA / Zoology's GatedLinearAttention) which drops the
    denominator. Use this for fair kernel-swap comparisons against FLA's GLA
    baseline; use the V+1 variant when you want the in-house normalized form.

    State formula drops the +d_qk denominator term:
      state = n_heads · num_chunks · d_qk · d_v   (no +d_qk)
    """
    uses_v_plus_one = False

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        write_gates = self._write_gates(x, k)
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        g = F.logsigmoid(self.w_g(x).view(B, L, H, self.d_qk))
        alpha = g.exp()
        alpha_chunk = 1.0 - write_gates.unsqueeze(-1) * (1.0 - alpha.unsqueeze(3))
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        # No V+1: gate v directly (no concat-of-ones, no num/den division).
        v_virt = v.unsqueeze(3) * write_gates.unsqueeze(-1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v)
        out_flat, _ = chunk_gla(q_flat, k_flat, v_flat, g_flat, scale=1.0)
        return out_flat.view(B, L, H, C, self.d_v)


class SoftmaxGDNWriter(WriterBase):
    """CLA writer with Gated DeltaNet inner kernel. MoM's default backbone, chunked.

    GDN kernel L2-normalizes q,k internally; no ELU+1 activation applied here.
    """
    uses_v_plus_one = False     # GDN uses delta rule, no V+1 denominator trick.
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None, route_on='x'):
        super().__init__()
        self.n_heads = n_heads
        self.num_chunks = num_chunks
        self.d_qk = d_qk
        self.d_v = d_v
        self.route_on = route_on
        if route_on == 'kq':
            self.W_route = nn.Parameter(torch.empty(n_heads, d_qk, num_chunks))
            _maybe_init_router_param(self.W_route, role='write')
        elif router is None:
            self.router = nn.Linear(d_model, n_heads * num_chunks, bias=False)
            _maybe_init_router(self.router, role='write')
        else:
            self.router = router
        self.w_g = nn.Linear(d_model, n_heads, bias=False)
        self.w_beta = nn.Linear(d_model, n_heads, bias=False)

    def _write_gates(self, x, k):
        B, L = x.shape[0], x.shape[1]
        H, C = self.n_heads, self.num_chunks
        if self.route_on == 'kq':
            logits = torch.einsum('blhd,hdc->blhc', k, self.W_route)
        else:
            logits = self.router(x).view(B, L, H, C)
        return F.softmax(logits, dim=-1)

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        write_gates = self._write_gates(x, k)
        g = F.logsigmoid(self.w_g(x).view(B, L, H))
        beta = torch.sigmoid(self.w_beta(x).view(B, L, H))
        # alpha_chunk = 1 - w*(1-alpha): w=0 preserve, w=1 full decay.
        # beta_chunk  = w * beta:         w=0 no delta,  w=1 full delta.
        alpha = g.exp().unsqueeze(3)                          # [B,L,H,1]
        alpha_chunk = 1.0 - write_gates * (1.0 - alpha)       # [B,L,H,C]
        beta_chunk = write_gates * beta.unsqueeze(3)          # [B,L,H,C]
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        beta_virt = beta_chunk
        v_virt = v.unsqueeze(3).expand(-1, -1, -1, C, -1)     # shared v (additive controlled by beta_chunk)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C)
        beta_flat = beta_virt.reshape(B, L, H * C)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v)
        out, _ = chunk_gated_delta_rule(q_flat, k_flat, v_flat, g_flat, beta_flat,
                                        use_qk_l2norm_in_kernel=True)
        return out.view(B, L, H, C, self.d_v)


class SigmoidLinearWriter(SoftmaxLinearWriter):
    """CLA writer with LA inner kernel; sigmoid (independent, non-competitive) write gates.
    Hypothesis: writing to multiple chunks at full strength is fine since write is a
    routing/storage decision; only reading needs to be competitive."""
    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        write_gates = torch.sigmoid(self.router(x).view(B, L, H, C))  # independent per chunk
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        v_virt = v_aug.unsqueeze(3) * write_gates.unsqueeze(-1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v + 1)
        raw_out, _ = fused_chunk_linear_attn(q_flat, k_flat, v_flat, normalize=False, scale=1.0)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out_flat = num / (den + 1e-5)
        return out_flat.view(B, L, H, C, self.d_v)


class SigmoidGLAWriter(SoftmaxGLAWriter):
    """CLA writer with GLA inner kernel; sigmoid write gates."""
    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        write_gates = torch.sigmoid(self.router(x).view(B, L, H, C))
        g = F.logsigmoid(self.w_g(x).view(B, L, H, self.d_qk))
        alpha = g.exp()
        alpha_chunk = 1.0 - write_gates.unsqueeze(-1) * (1.0 - alpha.unsqueeze(3))
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        v_virt = v_aug.unsqueeze(3) * write_gates.unsqueeze(-1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v + 1)
        raw_out, _ = chunk_gla(q_flat, k_flat, v_flat, g_flat, scale=1.0)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out_flat = num / (den + 1e-5)
        return out_flat.view(B, L, H, C, self.d_v)


def _cosine_logits(router, x, tau):
    """Compute logits = cosine(x, W_rows) / tau, where W_rows are router's output directions.

    This decouples the 'direction' of routing (which prototype to pick) from the 'sharpness'
    (how decisively). Raw Linear dot products entangle these; cosine + learnable tau
    separates them, giving the optimizer a clean gradient on sharpness via tau alone.
    """
    x_norm = F.normalize(x, dim=-1)
    W_norm = F.normalize(router.weight, dim=-1)  # [out_dim, d_model] normalized per row
    logits = F.linear(x_norm, W_norm)  # [B, L, out_dim], = cosine(x, W_row) per output
    return logits / tau.abs().clamp(min=1e-3)


class CosineSoftmaxLinearWriter(SoftmaxLinearWriter):
    """CLA-LA writer with cosine-similarity routing + learnable temperature.

    Decouples routing direction (router weights) from routing sharpness (tau).
    Writers initialize tau=1.0; the model learns whether it needs to be softer (larger tau,
    writes spread across chunks) or sharper (smaller tau, writes commit to one chunk)."""
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None):
        super().__init__(d_model, n_heads, num_chunks, d_qk, d_v, router)
        self.tau = nn.Parameter(torch.ones(1))

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        logits = _cosine_logits(self.router, x, self.tau).view(B, L, H, C)
        write_gates = F.softmax(logits, dim=-1)
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        v_virt = v_aug.unsqueeze(3) * write_gates.unsqueeze(-1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v + 1)
        raw_out, _ = fused_chunk_linear_attn(q_flat, k_flat, v_flat, normalize=False, scale=1.0)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out_flat = num / (den + 1e-5)
        return out_flat.view(B, L, H, C, self.d_v)


class CosineSoftmaxGLAWriter(SoftmaxGLAWriter):
    """CLA-GLA writer with cosine-similarity routing + learnable tau."""
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None):
        super().__init__(d_model, n_heads, num_chunks, d_qk, d_v, router)
        self.tau = nn.Parameter(torch.ones(1))

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        logits = _cosine_logits(self.router, x, self.tau).view(B, L, H, C)
        write_gates = F.softmax(logits, dim=-1)
        g = F.logsigmoid(self.w_g(x).view(B, L, H, self.d_qk))
        alpha = g.exp()
        alpha_chunk = 1.0 - write_gates.unsqueeze(-1) * (1.0 - alpha.unsqueeze(3))
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        v_virt = v_aug.unsqueeze(3) * write_gates.unsqueeze(-1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C, self.d_qk)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v + 1)
        raw_out, _ = chunk_gla(q_flat, k_flat, v_flat, g_flat, scale=1.0)
        num = raw_out[..., :-1]
        den = raw_out[..., -1:]
        out_flat = num / (den + 1e-5)
        return out_flat.view(B, L, H, C, self.d_v)


class CosineSoftmaxGDNWriter(SoftmaxGDNWriter):
    """CLA-GDN writer with cosine-similarity routing + learnable tau."""
    def __init__(self, d_model, n_heads, num_chunks, d_qk, d_v, router=None):
        super().__init__(d_model, n_heads, num_chunks, d_qk, d_v, router)
        self.tau = nn.Parameter(torch.ones(1))

    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        logits = _cosine_logits(self.router, x, self.tau).view(B, L, H, C)
        write_gates = F.softmax(logits, dim=-1)
        g = F.logsigmoid(self.w_g(x).view(B, L, H))
        beta = torch.sigmoid(self.w_beta(x).view(B, L, H))
        alpha = g.exp().unsqueeze(3)
        alpha_chunk = 1.0 - write_gates * (1.0 - alpha)
        beta_chunk = write_gates * beta.unsqueeze(3)
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        beta_virt = beta_chunk
        v_virt = v.unsqueeze(3).expand(-1, -1, -1, C, -1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C)
        beta_flat = beta_virt.reshape(B, L, H * C)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v)
        out, _ = chunk_gated_delta_rule(q_flat, k_flat, v_flat, g_flat, beta_flat,
                                        use_qk_l2norm_in_kernel=True)
        return out.view(B, L, H, C, self.d_v)


class SigmoidGDNWriter(SoftmaxGDNWriter):
    """CLA writer with GDN inner kernel; sigmoid (non-competitive) write gates.
    Tests whether the write-decision benefits from being permissive while the
    read remains spiky/competitive via the SoftmaxLinearReader."""
    def forward(self, x, q, k, v):
        B, L, _ = x.shape
        H, C = self.n_heads, self.num_chunks
        write_gates = torch.sigmoid(self.router(x).view(B, L, H, C))  # independent per chunk
        g = F.logsigmoid(self.w_g(x).view(B, L, H))
        beta = torch.sigmoid(self.w_beta(x).view(B, L, H))
        alpha = g.exp().unsqueeze(3)
        alpha_chunk = 1.0 - write_gates * (1.0 - alpha)
        beta_chunk = write_gates * beta.unsqueeze(3)
        q_virt = q.unsqueeze(3).expand(-1, -1, -1, C, -1)
        k_virt = k.unsqueeze(3).expand(-1, -1, -1, C, -1)
        g_virt = alpha_chunk.clamp(min=1e-8).log()
        beta_virt = beta_chunk
        v_virt = v.unsqueeze(3).expand(-1, -1, -1, C, -1)
        q_flat = q_virt.reshape(B, L, H * C, self.d_qk)
        k_flat = k_virt.reshape(B, L, H * C, self.d_qk)
        g_flat = g_virt.reshape(B, L, H * C)
        beta_flat = beta_virt.reshape(B, L, H * C)
        v_flat = v_virt.reshape(B, L, H * C, self.d_v)
        out, _ = chunk_gated_delta_rule(q_flat, k_flat, v_flat, g_flat, beta_flat,
                                        use_qk_l2norm_in_kernel=True)
        return out.view(B, L, H, C, self.d_v)


# Registry of available writers/readers. The CLA constructor looks up these
# names from kwargs ('writer' / 'reader' strings) so configs stay JSON-friendly.
WRITER_REGISTRY = {
    'softmax_linear': SoftmaxLinearWriter,
    'softmax_gla': SoftmaxGLAWriter,
    'softmax_gla_nov1': SoftmaxGLANoV1Writer,  # No V+1: matches base GLA / FLA's GLA
    'softmax_gdn': SoftmaxGDNWriter,
    'sigmoid_linear': SigmoidLinearWriter,
    'sigmoid_gla': SigmoidGLAWriter,
    'sigmoid_gdn': SigmoidGDNWriter,
    'cosine_softmax_linear': CosineSoftmaxLinearWriter,
    'cosine_softmax_gla': CosineSoftmaxGLAWriter,
    'cosine_softmax_gdn': CosineSoftmaxGDNWriter,
}
READER_REGISTRY = {
    'softmax_linear': SoftmaxLinearReader,
    'cosine_softmax_linear': CosineSoftmaxLinearReader,
}


class ChunkedLinearAttention(nn.Module):
    """
    Chunked Linear Attention (CLA).

    Pluggable architecture:
      - Common: project x → (q, k, v) with ELU+1 on q,k.
      - Writer: produces per-chunk attention outputs [B,L,H,C,d_v].
      - Reader: merges per-chunk outputs into [B,L,H,d_v].
      - Output projection: [B,L,H*d_v] → [B,L,d_model].

    Pick variants via the `writer` / `reader` kwargs (string names in the
    registries above). When `tie_routers=True`, the reader's router shares
    weights with the writer's (symmetric routing).
    """
    def __init__(self, d_model, d_qk, d_v, num_chunks, n_heads=4, tie_routers=False,
                 writer='softmax_linear', reader='softmax_linear',
                 use_short_conv=False, conv_size=4, route_on='x', **kwargs):
        super().__init__()
        self.d_model = d_model
        self.d_qk = d_qk
        self.d_v = d_v
        self.n_heads = n_heads
        self.num_chunks = num_chunks
        self.tie_routers = tie_routers
        self.route_on = route_on
        if route_on == 'kq' and tie_routers:
            # k-routing for writer and q-routing for reader can't naturally share weights.
            raise ValueError("route_on='kq' is incompatible with tie_routers=True")

        self.dim_inner_qk = n_heads * d_qk
        self.dim_inner_v = n_heads * d_v

        # Shared projections (always present, identical across variants).
        self.w_q = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_k = nn.Linear(d_model, self.dim_inner_qk, bias=False)
        self.w_v = nn.Linear(d_model, self.dim_inner_v, bias=False)
        self.w_o = nn.Linear(self.dim_inner_v, d_model, bias=False)

        # Optional short causal 1D conv over q/k/v (matching FLA's GDN inductive bias).
        # Kernel size `conv_size` (default 4); causal padding to preserve sequence length.
        self.use_short_conv = use_short_conv
        if use_short_conv:
            self.conv_size = conv_size
            self.conv_pad = conv_size - 1
            self.q_conv = nn.Conv1d(self.dim_inner_qk, self.dim_inner_qk,
                                    kernel_size=conv_size, groups=self.dim_inner_qk, bias=False)
            self.k_conv = nn.Conv1d(self.dim_inner_qk, self.dim_inner_qk,
                                    kernel_size=conv_size, groups=self.dim_inner_qk, bias=False)
            self.v_conv = nn.Conv1d(self.dim_inner_v,  self.dim_inner_v,
                                    kernel_size=conv_size, groups=self.dim_inner_v,  bias=False)

        writer_cls = WRITER_REGISTRY[writer]
        reader_cls = READER_REGISTRY[reader]
        writer_kwargs = dict(d_model=d_model, n_heads=n_heads, num_chunks=num_chunks,
                             d_qk=d_qk, d_v=d_v)
        reader_kwargs = dict(d_model=d_model, n_heads=n_heads, num_chunks=num_chunks,
                             d_qk=d_qk, d_v=d_v)
        # Pass route_on only if the writer/reader accepts it (some variants may not).
        import inspect
        if 'route_on' in inspect.signature(writer_cls.__init__).parameters:
            writer_kwargs['route_on'] = route_on
        if 'route_on' in inspect.signature(reader_cls.__init__).parameters:
            reader_kwargs['route_on'] = route_on
        self.writer = writer_cls(**writer_kwargs)
        if tie_routers and hasattr(self.writer, 'router'):
            self.reader = reader_cls(router=self.writer.router, **reader_kwargs)
        else:
            self.reader = reader_cls(**reader_kwargs)
        # Print actual instantiated state size in a parseable form so external
        # runners can log the *real* state per model (not formula-derived).
        if os.environ.get('CLA_PRINT_STATE_JSON', '1') != '0':
            try:
                import json as _json
                _stats = self.get_stats()
                _stats['writer'] = writer
                _stats['reader'] = reader
                _stats['route_on'] = route_on
                print(f"STATE_FLOATS_JSON {_json.dumps(_stats)}", flush=True)
            except Exception:
                pass

    def forward(self, x):
        B, L, _ = x.shape
        H = self.n_heads
        # Raw projections — each writer applies its own activation (ELU+1 for LA/GLA kernels,
        # none for GDN which L2-normalizes internally).
        q = self.w_q(x)  # [B, L, dim_inner_qk]
        k = self.w_k(x)
        v = self.w_v(x)
        if self.use_short_conv:
            # Causal depthwise conv + SiLU, matching FLA's ShortConvolution behavior.
            # Layout for conv1d: [B, C, L]; pad left by (kernel-1).
            def _cconv(xx, conv):
                xx = xx.transpose(1, 2)
                xx = F.pad(xx, (self.conv_pad, 0))
                xx = conv(xx)
                return F.silu(xx.transpose(1, 2))
            q = _cconv(q, self.q_conv)
            k = _cconv(k, self.k_conv)
            v = _cconv(v, self.v_conv)
        q = q.view(B, L, H, self.d_qk)
        k = k.view(B, L, H, self.d_qk)
        v = v.view(B, L, H, self.d_v)
        chunk_outputs = self.writer(x, q, k, v)            # [B, L, H, C, d_v]
        if self.route_on == 'kq':
            out = self.reader(x, chunk_outputs, q=q)
        else:
            out = self.reader(x, chunk_outputs)
        return self.w_o(out.reshape(B, L, H * self.d_v))

    def get_stats(self):
        """Returns a dictionary of key hyperparameters and calculated state size."""
        per_entry = self.d_qk * self.d_v
        if getattr(self.writer, 'uses_v_plus_one', True):
            per_entry += self.d_qk  # V+1 denominator trick (LA/GLA)
        state_floats = self.n_heads * self.num_chunks * per_entry
        return {
            'd_qk': self.d_qk,
            'd_v': self.d_v,
            'n_heads': self.n_heads,
            'num_chunks': self.num_chunks,
            'state_floats': state_floats
        }

    def state_size(self, sequence_length: int = None, **kwargs) -> int:
        # Zoology's Hybrid.state_size / model.state_size_total call this on
        # every mixer. Recurrent state is independent of sequence_length.
        return self.get_stats()['state_floats']


class DenseChunkedLinearAttention(nn.Module):
    """
    Dense Chunked Linear Attention (DCLA).
    
    Concept:
    - Independent Projections (Mixture of Memories).
    - Every Chunk has its own weights.
    - Sparse Read Routing.
    """
    def __init__(self, d_model, d_qk, d_v, num_chunks, n_heads=4, **kwargs):
        super().__init__()
        self.d_model = d_model
        self.d_qk = d_qk
        self.d_v = d_v
        self.n_heads = n_heads
        self.num_chunks = num_chunks
        
        # Total independent streams
        self.total_streams = n_heads * num_chunks
        
        # Massive Fused Projection
        self.w_qkv = nn.Linear(d_model, 
                               self.total_streams * (d_qk + d_qk + d_v), 
                               bias=False)
        
        # Read Router
        self.router = nn.Linear(d_model, self.total_streams, bias=False) 
        self.w_o = nn.Linear(n_heads * d_v, d_model, bias=False)

    def forward(self, x):
        B, L, _ = x.shape
        H = self.n_heads
        C = self.num_chunks
        Total = self.total_streams

        # 1. Get Q, K, V for all streams (H*C)
        # [B, L, Total, d_qk+d_qk+d_v]
        qkv = self.w_qkv(x).view(B, L, Total, self.d_qk + self.d_qk + self.d_v)
        
        # Split into q, k, v
        q, k, v = torch.split(qkv, [self.d_qk, self.d_qk, self.d_v], dim=-1)

        # 2. Enforce Positivity
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0

        # 3. Denominator Trick
        v_aug = torch.cat([v, torch.ones_like(v[..., :1])], dim=-1)
        
        # 4. Kernel Call
        # Processes H*C streams in parallel
        chunk_outputs_raw, _ = fused_chunk_linear_attn(q, k, v_aug, normalize=False, scale=1.0)
        
        # 5. Normalize
        num = chunk_outputs_raw[..., :-1]
        den = chunk_outputs_raw[..., -1:]
        chunk_outputs = num / (den + 1e-5) # [B, L, Total, D_v]

        # 6. Route & Aggregate
        # Reshape to separate Heads and Chunks
        chunk_outputs = chunk_outputs.view(B, L, H, C, self.d_v)

        # Route Read: [B, L, H*C] -> [B, L, H, C]
        read_logits = self.router(x).view(B, L, H, C)
        read_gates = F.softmax(read_logits, dim=-1)
        
        # Aggregate
        aggregated = torch.sum(read_gates.unsqueeze(-1) * chunk_outputs, dim=3)
        
        # Final Projection
        return self.w_o(aggregated.reshape(B, L, H*self.d_v))

    def get_stats(self):
        """Returns a dictionary of key hyperparameters and calculated state size."""
        # For DCLA, state is calculated based on total streams
        state_floats = self.total_streams * (self.d_qk * self.d_v + self.d_qk)
        return {
            'd_qk': self.d_qk,
            'd_v': self.d_v,
            'n_heads': self.n_heads,
            'num_chunks': self.num_chunks,
            'state_floats': state_floats
        }


# ========================================== 
# 3. Model Wrapper
# ========================================== 

class RecurrentChunkAttention(nn.Module):
    """A wrapper that routes to the correct attention implementation."""
    def __init__(self, d_model, attention_type, **kwargs):
        super().__init__()
        self.attention_type = attention_type

        # Route to the correct implementation
        if attention_type == 'rla':
            self.impl = RecurrentLinearAttention(d_model=d_model, **kwargs)
        elif attention_type == 'gla':
            self.impl = RecurrentGLA(d_model=d_model, **kwargs)
        elif attention_type == 'gdn':
            self.impl = RecurrentGatedDelta(d_model=d_model, **kwargs)
        elif attention_type == 'cla':
            self.impl = ChunkedLinearAttention(d_model=d_model, **kwargs)
        elif attention_type == 'dcla':
            self.impl = DenseChunkedLinearAttention(d_model=d_model, **kwargs)
        else:
            raise ValueError(f"Unknown attention type: {attention_type}")

    def forward(self, x):
        return self.impl(x)

class DecoderBlock(nn.Module):
    def __init__(self, d_model, attention_type, **kwargs):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attn = RecurrentChunkAttention(d_model, attention_type, **kwargs)
        self.norm2 = nn.LayerNorm(d_model)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.GELU(),
            nn.Linear(d_model * 4, d_model),
            nn.Dropout(0.1),
        )
        self.dropout = nn.Dropout(0.1)

    def forward(self, x):
        x = x + self.dropout(self.attn(self.norm1(x)))
        x = x + self.dropout(self.mlp(self.norm2(x)))
        return x

class DeepModel(nn.Module):
    def __init__(self, vocab_size, seq_len, d_model, num_layers, attention_type, **kwargs):
        super().__init__()
        self.d_model = d_model
        self.emb = nn.Embedding(vocab_size, self.d_model) 
        self.pos_emb = nn.Parameter(torch.zeros(1, seq_len, self.d_model))
        nn.init.normal_(self.pos_emb, mean=0, std=0.02)
        self.dropout = nn.Dropout(0.1)
        
        self.layers = nn.ModuleList([
            DecoderBlock(d_model, attention_type, **kwargs) for _ in range(num_layers)
        ])
        
        self.head = nn.Linear(self.d_model, vocab_size)
        
    def forward(self, x):
        B, L = x.shape
        x = self.dropout(self.emb(x) + self.pos_emb[:, :L, :])
        for layer in self.layers:
            x = layer(x)
        return self.head(x)
        
    def print_stats(self):
        """Prints Parameter and Memory usage statistics."""
        total_params = sum(p.numel() for p in self.parameters())
        
        # Correctly access the implementation's stats
        stats = self.layers[0].attn.impl.get_stats()
        state_floats = stats['state_floats']
        state_kb = (state_floats * 4) / 1024  # assuming float32

        log_print(f"[{self.layers[0].attn.attention_type.upper()}] Stats:")
        log_print(f"  > Params:      {total_params:,}")
        log_print(f"  > State Size:  {state_floats:,} floats (~{state_kb:.1f} KB/layer)")
        log_print(f"  > Config:      d_model={self.d_model}, d_qk={stats['d_qk']}, d_v={stats['d_v']}, layers={len(self.layers)}, chunks={stats['num_chunks']}, heads={stats['n_heads']}")
        log_print("-" * 40)

# ==========================================
# 4. Training Harness
# ==========================================
def train_and_evaluate(main_config, model_config, seed=42):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    log_print(f"\nInitializing {model_config['label']}...")
    
    provider = TextDatasetProvider(dataset_name=main_config['dataset'])
    train_loader, val_loader = provider.get_loaders(batch_size=32)
    
    model = DeepModel(
        vocab_size=provider.vocab_size, 
        seq_len=provider.seq_len,
        num_layers=main_config['num_layers'],
        **model_config
    ).to(DEVICE)
    model.print_stats()
    
    optimizer = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-2)
    criterion = nn.CrossEntropyLoss(ignore_index=-100)
    is_mqar = getattr(provider, 'is_mqar', False)

    def eval_metric(loader):
        """Returns (mean_loss, accuracy_or_None). Accuracy is over query positions for MQAR."""
        model.eval()
        losses = []
        correct = 0
        total = 0
        with torch.no_grad():
            for x_e, y_e in loader:
                x_e, y_e = x_e.to(DEVICE), y_e.to(DEVICE)
                logits_e = model(x_e)
                losses.append(criterion(logits_e.view(-1, provider.vocab_size), y_e.view(-1)).item())
                if is_mqar:
                    preds = logits_e.argmax(dim=-1)
                    mask = (y_e != -100)
                    correct += (preds[mask] == y_e[mask]).sum().item()
                    total += mask.sum().item()
        model.train()
        acc = (correct / total) if (is_mqar and total > 0) else None
        return float(np.mean(losses)), acc
    
    train_history = []
    val_history = []
    best_val_acc = 0.0
    step = 0
    model.train()
    start_time = time.time()
    VAL_EVAL_INTERVAL = 500
    
    while step <= main_config['steps']:
        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            step += 1
            
            optimizer.zero_grad()
            logits = model(x) 
            loss = criterion(logits.view(-1, provider.vocab_size), y.view(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            if step % 50 == 0:
                train_history.append(math.exp(min(loss.item(), 20)))
                if step % 500 == 0:
                    log_print(f"  Step {step}: Train Loss={loss.item():.4f} PPL={math.exp(min(loss.item(), 20)):.2f}")

            if step % VAL_EVAL_INTERVAL == 0:
                val_loss_mean, val_acc = eval_metric(val_loader)
                avg_val_ppl = math.exp(min(val_loss_mean, 20))
                val_history.append(avg_val_ppl if not is_mqar else (val_acc * 100))
                if is_mqar:
                    if val_acc > best_val_acc:
                        best_val_acc = val_acc
                    log_print(f"  Step {step}: Val Loss={val_loss_mean:.4f} QueryAcc={val_acc*100:.2f}% (best={best_val_acc*100:.2f}%)")
                else:
                    log_print(f"  Step {step}: Val Loss={val_loss_mean:.4f} PPL={avg_val_ppl:.2f}")
            
            if step > main_config['steps']: break
            
    training_time = time.time() - start_time
    
    log_print("  > Final Validation...")
    final_val_loss, final_val_acc = eval_metric(val_loader)
    if is_mqar:
        if final_val_acc > best_val_acc:
            best_val_acc = final_val_acc
        log_print(f"  > Finished. Final QueryAcc: {final_val_acc*100:.2f}% Best={best_val_acc*100:.2f}% (Loss: {final_val_loss:.4f}). Time: {training_time:.1f}s")
    else:
        final_val_ppl = math.exp(min(final_val_loss, 20))
        log_print(f"  > Finished. Final Validation PPL: {final_val_ppl:.2f} (Loss: {final_val_loss:.4f}). Time: {training_time:.1f}s")
    return train_history, val_history

# ==========================================
# 5. Main Execution
# ==========================================
if __name__ == "__main__":
    import argparse
    from datetime import datetime
    import uuid

    parser = argparse.ArgumentParser(description="Chunked Linear Attention Benchmark")
    parser.add_argument('--training_type', type=str, default='shakespeare', choices=['shakespeare', 'wikitext', 'mqar'],
                        help='Model configuration to use')
    args = parser.parse_args()

    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    output_dir = os.path.join('outputs', run_id)
    os.makedirs(output_dir, exist_ok=True)
    
    log_file_path = os.path.join(output_dir, "training_log.txt")
    log_file_handle = open(log_file_path, "w")

    def log_print(*args, **kwargs):
        print(*args, **kwargs)
        if log_file_handle:
            original_stdout = sys.stdout
            sys.stdout = log_file_handle
            print(*args, **kwargs)
            sys.stdout = original_stdout
            log_file_handle.flush()

    log_print(f"Starting run {run_id}. Outputs will be in {output_dir}")
    log_print(f"Running on device: {DEVICE}")

    MODEL_CONFIGS = {
        'shakespeare': {
            'dataset': 'shakespeare',
            'steps': 3000,
            'num_layers': 2,
            'models': [
                {'label': 'RLA', 'attention_type': 'rla', 'd_model': 128, 'n_heads': 4, 'd_qk': 32, 'd_v': 32},
                {'label': 'CLA', 'attention_type': 'cla', 'd_model': 128, 'n_heads': 4, 'd_qk': 16, 'd_v': 32, 'num_chunks': 2},
            ]
        },
        'wikitext': {
            'dataset': 'wikitext',
            'steps': 5000,
            'num_layers': 2,
            'models': [
                {'label': 'RLA', 'attention_type': 'rla', 'd_model': 128, 'n_heads': 4, 'd_qk': 32, 'd_v': 32},
                {'label': 'CLA', 'attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 12, 'd_v': 21, 'num_chunks': 8},
            ]
        },
        'mqar': {
            # All CLA configs match RLA's state size of 4224 floats:
            #   RLA:   4 * 1 * (32*32 + 32) = 4224
            #   CLA-2: 2 * 2 * (24*43 + 24) = 4224
            #   CLA-4: 2 * 4 * (16*32 + 16) = 4224
            #   CLA-8: 2 * 8 * (12*21 + 12) = 4224
            # Each CLA chunk count is run twice: once with asymmetric routers (sep
            # router_write/router_read) and once with symmetric (tied weights).
            # This isolates Weigao's question: does the asymmetry actually matter?
            'dataset': 'mqar',
            'steps': 3000,
            'num_layers': 2,
            'models': [
                {'label': 'RLA',       'attention_type': 'rla', 'd_model': 128, 'n_heads': 4, 'd_qk': 32, 'd_v': 32},
                {'label': 'CLA-2-sym', 'attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 24, 'd_v': 43, 'num_chunks': 2, 'tie_routers': True},
                {'label': 'CLA-2-asym','attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 24, 'd_v': 43, 'num_chunks': 2, 'tie_routers': False},
                {'label': 'CLA-4-sym', 'attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 16, 'd_v': 32, 'num_chunks': 4, 'tie_routers': True},
                {'label': 'CLA-4-asym','attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 16, 'd_v': 32, 'num_chunks': 4, 'tie_routers': False},
                {'label': 'CLA-8-sym', 'attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 12, 'd_v': 21, 'num_chunks': 8, 'tie_routers': True},
                {'label': 'CLA-8-asym','attention_type': 'cla', 'd_model': 128, 'n_heads': 2, 'd_qk': 12, 'd_v': 21, 'num_chunks': 8, 'tie_routers': False},
            ]
        }
    }
    
    main_config = MODEL_CONFIGS[args.training_type]
    SEED = int(os.environ.get('MQAR_SEED', 1337))
    if 'MQAR_STEPS' in os.environ:
        main_config['steps'] = int(os.environ['MQAR_STEPS'])

    results = {}
    for model_config in main_config['models']:
        train_hist, val_hist = train_and_evaluate(
            main_config=main_config,
            model_config=model_config,
            seed=SEED
        )
        results[model_config['label']] = (train_hist, val_hist)
    
    # --- Plotting ---
    VAL_EVAL_INTERVAL = 500
    val_steps = np.arange(VAL_EVAL_INTERVAL, main_config['steps'] + 1, VAL_EVAL_INTERVAL)
    train_steps_raw = np.arange(50, main_config['steps'] + 1, 50)

    # Plot 1: Training Perplexity
    plt.figure(figsize=(12, 8))
    cmap = plt.get_cmap('tab10')
    for i, (label, (train_hist, _)) in enumerate(results.items()):
        train_steps_smoothed = train_steps_raw[len(train_steps_raw)-len(train_hist):]
        style = '--' if 'sym' in label and 'asym' not in label else '-'
        plt.plot(train_steps_smoothed, train_hist, label=label, color=cmap(i % 10), linestyle=style)

    plt.title(f'Training Perplexity ({main_config["dataset"].capitalize()}, {args.training_type} Model)')
    plt.xlabel('Training Steps')
    plt.ylabel('Perplexity (PPL)')
    plt.yscale('log')
    plt.legend()
    plt.grid(True, which="both", ls="--", alpha=0.5)
    train_output_file = os.path.join(output_dir, f'benchmark_{args.training_type}_train.png')
    plt.savefig(train_output_file)
    log_print(f"\nTraining graph saved to {train_output_file}")

    # Plot 2: Validation Perplexity
    plt.figure(figsize=(12, 8))
    markers = ['o', 'x', '+', 's', 'D', '^', 'v', '*', 'p', 'h']
    for i, (label, (_, val_hist)) in enumerate(results.items()):
         plt.plot(val_steps[:len(val_hist)], val_hist, marker=markers[i % len(markers)], linestyle='--', label=label, color=cmap(i % 10))

    is_mqar_plot = (main_config['dataset'] == 'mqar')
    plt.title(f'Validation {"QueryAcc%" if is_mqar_plot else "Perplexity"} ({main_config["dataset"].capitalize()})')
    plt.xlabel('Training Steps')
    plt.ylabel('Query Accuracy (%)' if is_mqar_plot else 'Perplexity (PPL)')
    if not is_mqar_plot:
        plt.yscale('log')
    plt.legend()
    plt.grid(True, which="both", ls="--", alpha=0.5)
    val_output_file = os.path.join(output_dir, f'benchmark_{args.training_type}_val.png')
    plt.savefig(val_output_file)
    log_print(f"Validation graph saved to {val_output_file}")
    
    log_file_handle.close()
