#!/usr/bin/env bash
# Set up budget alerts at $200/$250/$280 of $300 total.
# Reads cloud/.env. Sends email alerts to BUDGET_EMAIL.
set -eu

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/.env" ]; then
    set -a; source "$SCRIPT_DIR/.env"; set +a
fi

: "${GCP_PROJECT_ID:?GCP_PROJECT_ID not set}"
: "${BILLING_ACCOUNT_ID:?BILLING_ACCOUNT_ID not set — find via 'gcloud beta billing accounts list'}"
: "${BUDGET_EMAIL:?BUDGET_EMAIL not set}"

GCLOUD="${GCLOUD:-/mnt/c/Users/Blake/AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin/gcloud}"

echo "Creating $300 budget on project $GCP_PROJECT_ID with email alerts at \$200/\$250/\$280..."
"$GCLOUD" beta billing budgets create \
    --billing-account="$BILLING_ACCOUNT_ID" \
    --display-name="cla-sweep-budget-300" \
    --budget-amount=300USD \
    --threshold-rule=percent=0.67 \
    --threshold-rule=percent=0.83 \
    --threshold-rule=percent=0.93 \
    --threshold-rule=percent=1.00 \
    --filter-projects="projects/$GCP_PROJECT_ID" \
    --all-updates-rule-monitoring-notification-channels="" \
    2>&1 || echo "Budget API command above may need the beta component installed first."

echo ""
echo "If the above didn't work, the easiest fallback is the web console:"
echo "  https://console.cloud.google.com/billing/budgets?project=$GCP_PROJECT_ID"
echo "  → CREATE BUDGET → \$300 USD → alerts at 67%/83%/93%/100% → email $BUDGET_EMAIL"
