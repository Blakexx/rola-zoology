# Cloud sweep infrastructure

Generic Vertex AI CustomJob submission for any `run_*.py` sweep in this repo.

## Files

| File | Purpose |
|---|---|
| `Dockerfile` | Generic image: PyTorch NGC base + FLA + Triton + project code. |
| `cloudbuild.yaml` | Cloud Build config — builds image remotely, pushes to Artifact Registry. |
| `requirements-cloud.txt` | Python deps installed inside the image (on top of NGC PyTorch). |
| `shard_runner.py` | Entrypoint inside the container. Loads any `run_*.py`, processes its shard, writes results to GCS with resume. |
| `submit.py` | Local-machine command-line tool. Submits N parallel CustomJobs each running a different shard. |
| `setup_budget.sh` | Creates $300 budget with email alerts at 67%/83%/93%/100%. |
| `.env.example` | Template config. Copy to `.env` and fill values. **`.env` is gitignored.** |

## One-time setup

1. **Authenticate gcloud** (already done):
   ```
   gcloud auth login
   gcloud auth application-default login
   gcloud config set project <YOUR_PROJECT_ID>
   ```

2. **Enable APIs**:
   ```
   gcloud services enable aiplatform.googleapis.com \
       artifactregistry.googleapis.com \
       cloudbuild.googleapis.com \
       compute.googleapis.com \
       storage.googleapis.com
   ```

3. **Create Artifact Registry repo + GCS bucket** (already done for this project):
   ```
   gcloud artifacts repositories create cla-sweep \
       --repository-format=docker --location=us-central1
   gcloud storage buckets create gs://YOUR_BUCKET_NAME --location=us-central1
   ```

4. **Configure .env** — copy `.env.example` to `.env` and fill in:
   - `GCP_PROJECT_ID` — your project ID
   - `GCP_REGION` — `us-central1` recommended (A100 available)
   - `GCS_BUCKET` — bucket name from step 3
   - `BUDGET_EMAIL` — for budget alerts

5. **Optional: budget alerts** — `bash cloud/setup_budget.sh` (needs `BILLING_ACCOUNT_ID` in .env)

## Build the image

From the project root:

```
gcloud builds submit --config=cloud/cloudbuild.yaml .
```

This builds the Docker image on Cloud Build (no local Docker needed) and pushes it to
`<region>-docker.pkg.dev/<project>/cla-sweep/sweep:latest`. Takes ~5-10 min.

## Submit a sweep

Generic invocation:

```
python cloud/submit.py \
    --runner run_zoology_canonical_scan.py \
    --num-shards 4 \
    --gcs-results gs://cla-zoology-sweep-538989c8/zoology_canonical/results.jsonl \
    --machine a2-highgpu-1g \
    --accelerator NVIDIA_TESLA_A100 \
    --spot
```

Each of the 4 CustomJobs spins up a 1× A100 40GB VM, runs `shard_runner.py` which
loads `run_zoology_canonical_scan.py` and processes only `idx % 4 == shard_idx`.
All shards append to the same GCS results file (read on startup → resume).

### Useful flags

- `--max-runs-per-shard 2` — testing; run only 2 jobs per shard before exiting.
- `--extra-env KEY=VAL` — repeatable; injected into every shard's env (e.g. `MQAR_*`).
- `--dry-run` — print the job specs without submitting.
- `--accelerator-count 2` — multi-GPU per replica (most of our cells are single-GPU).

### Picking machine + accelerator

| Need | Machine | Accelerator | Spot $/hr |
|---|---|---|---:|
| Most cells, safe margin | `a2-highgpu-1g` | `NVIDIA_TESLA_A100` × 1 | ~$1.50 |
| Big-state cells (524k) | `a2-ultragpu-1g` | `NVIDIA_TESLA_A100_80GB` × 1 | ~$2.30 |
| Cheap, small cells only | `g2-standard-8` | `NVIDIA_L4` × 1 | ~$0.20 |

## Watching progress

- Vertex AI console: <https://console.cloud.google.com/vertex-ai/training/custom-jobs>
- Each job streams stdout to Cloud Logging.
- Results: `gsutil cat gs://YOUR_BUCKET/path/results.jsonl | wc -l` to count completed runs.
- Or stream the local mirror inside the container: `/tmp/shard_N_of_M.jsonl`.

## Pulling results back to local

```
gsutil cp gs://YOUR_BUCKET/path/results.jsonl /home/blake/zoology/results.jsonl
```

## Costs (rough)

| Workload | Shards | Wall time | Total spend |
|---|---:|---:|---:|
| zoology_canonical_scan (810 remaining runs) | 1 spot A100 40GB | ~50 h | ~$80 |
| Same, 4 shards | 4 | ~13 h | ~$80 |
| Same, 8 shards | 8 | ~7 h | ~$80 |

(Cost is total compute hours × hourly rate; parallelism saves wall time, not money.)

## Sensitive data

`cloud/.env` (with project ID / bucket name) is gitignored. The `.env.example`
template is safe to commit. **Do not** commit service-account JSON keys; the
`.gitignore` blocks the obvious patterns (`service-account*.json`, `*-key.json`,
`application_default_credentials.json`, etc.).
