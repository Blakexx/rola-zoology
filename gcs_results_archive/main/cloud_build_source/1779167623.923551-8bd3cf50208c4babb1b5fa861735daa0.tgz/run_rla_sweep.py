"""Runner for RLA sweeps (full sweep and pilot share this runner).

Usage:
  python run_rla_sweep.py --config rla_sweep   # full 400-run sweep
  python run_rla_sweep.py --config rla_pilot   # 6-run G2 pilot
  python run_rla_sweep.py --config rla_sweep --shard 0/4   # one shard

Per-run JSONL fields:
  run_id, idx, ok, returncode, elapsed,
  max_acc, grok_ep, epochs_run,
  state_floats (read from STATE_FLOATS_JSON — actual instantiated state, NOT formula),
  n_params (total trainable, parsed from Zoology stdout if present),
  slice_accs (per-difficulty kv accuracy from slice_keys=["num_kv_pairs"]),
  valid_acc_curve, env, stderr_tail.
"""
import argparse, sys, os, json, time, pickle, subprocess, re
from pathlib import Path
import importlib.util

ZOO = Path(__file__).resolve().parent
PYTHON = sys.executable


def load_configs(name):
    spec = importlib.util.spec_from_file_location(
        name, ZOO / f"zoology/experiments/{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.configs, mod.configs_envs


def load_configs_and_envs():
    """Shard-runner entry point. Uses RLA_CONFIG env var (default rla_sweep)."""
    return load_configs(os.environ.get('RLA_CONFIG', 'rla_sweep'))


def parse_stdout(stdout):
    # Per-epoch valid/accuracy progression (Lightning progress bar)
    pairs = re.findall(
        r'Valid Epoch (\d+)/\d+: 100%\|[^\n\r]*valid/accuracy=([\d.]+)', stdout)
    pairs = [(int(e), float(a)) for e, a in pairs if 0 <= float(a) <= 1]
    max_acc = max((a for _, a in pairs), default=0.0)
    grok_ep = next((e for e, a in pairs if a >= 0.99), None)
    epochs_run = max((e for e, _ in pairs), default=0)
    valid_acc_curve = pairs

    # Per-kv slice accuracy (Zoology emits `valid/num_kv_pairs/accuracy-N=v`
    # via iterator.set_postfix at train.py:176 — the older regex looked for
    # `valid/accuracy/num_kv_pairs=N` which is the wrong order).
    slice_accs = {}
    for m in re.finditer(r'valid/num_kv_pairs/accuracy-(\d+)[^\d.]+([\d.]+)', stdout):
        kv, acc = int(m.group(1)), float(m.group(2))
        if 0 <= acc <= 1:
            slice_accs[kv] = max(slice_accs.get(kv, 0), acc)

    # CLA STATE_FLOATS_JSON — one per kernel layer. Capture all & sum n_heads ×
    # num_chunks × per_entry from each. For state-axis we use the per-layer
    # state (all kernel layers are identical), so just take the first.
    state_records = []
    for m in re.finditer(r'STATE_FLOATS_JSON (\{.*?\})', stdout):
        try:
            state_records.append(json.loads(m.group(1)))
        except Exception:
            pass
    state_floats = state_records[0]['state_floats'] if state_records else None
    state_per_layer = [r['state_floats'] for r in state_records] if state_records else []

    # MODEL_STATS_JSON line emitted by zoology/logger.py.
    n_params = None
    model_state_total = None
    m = re.search(r'MODEL_STATS_JSON (\{.*?\})', stdout)
    if m:
        try:
            ms = json.loads(m.group(1))
            n_params = ms.get('num_parameters')
            model_state_total = ms.get('state_size')
        except Exception:
            pass

    # FLOPS_JSON line (also from logger.py) — forward FLOPs at training batch
    # × seq_len, with disk-backed caching per unique cell config.
    # The flops_by_op dict is a nested dict so the older non-greedy regex won't
    # match cleanly; we use a more permissive single-line greedy match.
    fwd_flops = None
    flops_batch = None
    flops_seq = None
    flops_cache_hit = None
    flops_by_op = None
    flops_error = None
    m = re.search(r'^FLOPS_JSON (\{.*\})\s*$', stdout, re.MULTILINE)
    if m:
        try:
            fs = json.loads(m.group(1))
            fwd_flops = fs.get('forward_flops')
            flops_batch = fs.get('batch')
            flops_seq = fs.get('seq_len')
            flops_cache_hit = fs.get('cache_hit')
            flops_by_op = fs.get('flops_by_op')
            flops_error = fs.get('error')
        except Exception as e:
            flops_error = f"runner json parse failed: {e}; raw: {m.group(1)[:300]}"
    else:
        flops_error = "FLOPS_JSON not found in stdout"

    return dict(
        max_acc=max_acc, grok_ep=grok_ep, epochs_run=epochs_run,
        valid_acc_curve=valid_acc_curve, slice_accs=slice_accs,
        state_floats=state_floats, state_per_layer=state_per_layer,
        model_state_total=model_state_total,
        n_params=n_params,
        fwd_flops=fwd_flops,
        flops_by_op=flops_by_op,
        flops_batch=flops_batch,
        flops_seq=flops_seq,
        flops_cache_hit=flops_cache_hit,
        flops_error=flops_error,
    )


def run_one(idx, run_id, cfg, env_overrides, results_file=None):
    tmp_path = Path(f"/tmp/_rla_single_{idx}.py")
    tmp_path.write_text(
        "import pickle\n"
        f"with open('/tmp/_rla_cfg_{idx}.pkl', 'rb') as f:\n"
        "    configs = [pickle.load(f)]\n"
    )
    with open(f"/tmp/_rla_cfg_{idx}.pkl", "wb") as f:
        pickle.dump(cfg, f)

    env = os.environ.copy()
    env["WANDB_MODE"] = "offline"
    # Disable wandb's stdout interception so our FLOPS_JSON / MODEL_STATS_JSON
    # / STATE_FLOATS_JSON lines reliably reach the subprocess's captured stdout.
    # Without this, wandb's console-capture eats some of our prints (notably
    # FLOPS_JSON), leaving the runner unable to parse FLOPs.
    env["WANDB_CONSOLE"] = "off"
    # Clear any stale MQAR_* env from previous runs (recipe/router knobs).
    for k in list(env):
        if k.startswith("MQAR_ROUTER_STD") or k.startswith("MQAR_CURR"):
            del env[k]
    env.update(env_overrides)
    env["CLA_PRINT_STATE_JSON"] = "1"

    t0 = time.time()
    try:
        proc = subprocess.run(
            [PYTHON, "-m", "zoology.launch", str(tmp_path)],
            cwd=str(ZOO), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=7200,
        )
        elapsed = time.time() - t0
        ok = proc.returncode == 0
        parsed = parse_stdout(proc.stdout)
        return {
            "run_id": run_id, "idx": idx, "ok": ok, "elapsed": elapsed,
            "returncode": proc.returncode, "env": env_overrides,
            **parsed,
            "stderr_tail": proc.stdout[-2000:] if not ok else "",
        }
    except subprocess.TimeoutExpired:
        return {"run_id": run_id, "idx": idx, "ok": False, "elapsed": 7200, "error": "timeout"}
    finally:
        try:
            Path(f"/tmp/_rla_cfg_{idx}.pkl").unlink(missing_ok=True)
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="rla_sweep",
                    help="experiment module under zoology/experiments/ (rla_sweep | rla_pilot)")
    ap.add_argument("--results", default=None,
                    help="output jsonl path (default: <config>_results.jsonl in cwd)")
    ap.add_argument("--shard", default=None,
                    help="N/M to process only idx where idx %% M == N")
    args = ap.parse_args()

    configs, envs = load_configs(args.config)
    results_file = Path(args.results) if args.results else ZOO / f"{args.config}_results.jsonl"
    print(f"Loaded {len(configs)} {args.config} configs", flush=True)
    print(f"Results → {results_file}", flush=True)

    shard_n, shard_m = None, None
    if args.shard:
        n, m = args.shard.split("/")
        shard_n, shard_m = int(n), int(m)
        print(f"Shard {shard_n}/{shard_m} — processing idx where idx %% {shard_m} == {shard_n}", flush=True)

    completed = set()
    if results_file.exists():
        for line in open(results_file):
            try:
                r = json.loads(line)
                if r.get("ok"):
                    completed.add(r["idx"])
            except Exception:
                pass
    if completed:
        print(f"Resuming: skipping {len(completed)} done", flush=True)

    with open(results_file, "a") as fout:
        for i, (cfg, env_o) in enumerate(zip(configs, envs)):
            if shard_m is not None and i % shard_m != shard_n:
                continue
            if i in completed:
                continue
            run_id = cfg.run_id
            print(f"\n[{i+1}/{len(configs)}] {run_id} | env: {env_o}", flush=True)
            result = run_one(i, run_id, cfg, env_o, results_file)
            fout.write(json.dumps(result) + "\n")
            fout.flush()
            status = "OK" if result.get("ok") else f"FAIL ({result.get('error', result.get('returncode'))})"
            elapsed = result.get('elapsed', 0)
            epochs_run = result.get('epochs_run', 0) or 0
            n_ep = epochs_run + 1
            s_per_ep = elapsed / max(n_ep, 1)
            fwd = result.get('fwd_flops')
            fwd_str = (f"{fwd/1e9:.1f}G" if isinstance(fwd, (int, float)) and fwd else "n/a")
            cache_str = "cached" if result.get('flops_cache_hit') else "fresh"
            print(f"  → {status}, max_acc={result.get('max_acc', 0):.3f}, "
                  f"grok_ep={result.get('grok_ep')}, "
                  f"state={result.get('state_floats')}, "
                  f"params={result.get('n_params')}, "
                  f"fwd_flops={fwd_str} ({cache_str}), "
                  f"t={elapsed:.0f}s ({s_per_ep:.0f}s/ep × {n_ep}ep)", flush=True)


if __name__ == "__main__":
    main()
