#!/bin/bash
# Local docker smoke test — run the same container image that goes to Vertex,
# at a tiny scale, on your local GPU. Catches most "code in container is
# broken" issues before queuing spot Vertex jobs (which have 5-15 min wait).
#
# Usage:
#   ./cloud/smoke_local.sh                # uses :latest image
#   ./cloud/smoke_local.sh build-XXX...   # specific image tag
#
# Total runtime: ~1-2 min (pull image if not cached, then ~30s training).
# Cost: $0.
set -euo pipefail

IMAGE_TAG="${1:-latest}"
DOCKER="${DOCKER:-/mnt/c/Program Files/Docker/Docker/resources/bin/docker.exe}"

# Resolve image URI from cloud/.env
source "$(dirname "$0")/.env"
IMAGE="us-central1-docker.pkg.dev/${GCP_PROJECT_ID}/${AR_REPO}/sweep:${IMAGE_TAG}"

echo "=== Local smoke test ==="
echo "Image: ${IMAGE}"

# Ensure image is pulled
"$DOCKER" pull "${IMAGE}" 2>&1 | tail -3 || {
    echo "Pull failed. Auth? Run: gcloud auth configure-docker us-central1-docker.pkg.dev"
    exit 1
}

# Run the tiny smoke against this image, with results to local /tmp
RESULT_DIR=$(mktemp -d)
echo "Results dir: $RESULT_DIR"

"$DOCKER" run --rm --gpus all \
    -v "$RESULT_DIR:/tmp/smoke_out" \
    -e RLA_CONFIG=rla_smoke_tiny \
    "${IMAGE}" \
    --runner run_rla_sweep.py \
    --shard 0/1 \
    --gcs-results /tmp/smoke_out/results.jsonl \
    --max-runs 1 2>&1 | tail -25

echo ""
echo "=== Smoke result ==="
if [ -f "$RESULT_DIR/results.jsonl" ]; then
    python3 -c "
import json
r = json.load(open('$RESULT_DIR/results.jsonl'))
print(f'ok={r.get(\"ok\")}  elapsed={r.get(\"elapsed\"):.1f}s  max_acc={r.get(\"max_acc\")}')
if not r.get('ok'):
    print('FAILED — stderr:')
    print(r.get('stderr_tail', '')[-800:])
    exit(1)
" || exit 1
    echo "✓ SMOKE PASS — safe to submit Vertex jobs with this image"
else
    echo "✗ No result file written"
    exit 1
fi
